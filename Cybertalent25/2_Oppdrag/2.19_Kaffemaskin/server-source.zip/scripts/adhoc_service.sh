#!/bin/sh

echo "adhoc service"
