#!/bin/sh

echo "daily service"
