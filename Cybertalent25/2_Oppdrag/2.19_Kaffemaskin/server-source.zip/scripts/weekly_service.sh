#!/bin/sh

echo "weekly service"
